tinyMCE.addI18n('da.simple',{
bold_desc:"Fed (Ctrl+B)",
italic_desc:"Kursiv (Ctrl+I)",
underline_desc:"Understreget (Ctrl+U)",
striketrough_desc:"Gennemstreget",
bullist_desc:"Unummereret punktopstilling",
numlist_desc:"Nummereret punktopstilling",
undo_desc:"Fortryd (Ctrl+Z)",
redo_desc:"Gendan (Ctrl+Y)",
cleanup_desc:"Ryd op i uordentlig kode"
});